# Currency Converter

## Overview

The Currency Converter is a web application that allows users to convert amounts between different currencies using real-time exchange rates. The application provides a user-friendly interface for selecting currencies and viewing the conversion results, along with a graphical representation of the exchange rates.

## Features

- Convert between multiple currencies.
- Real-time exchange rates fetched from an external API.
- Interactive chart displaying the latest exchange rate.
- Responsive design for optimal viewing on various devices.

## Technologies Used

- **Node.js**: JavaScript runtime for building the server.
- **Express**: Web framework for Node.js to handle routing and server-side logic.
- **EJS**: Templating engine for rendering HTML views.
- **Axios**: Promise-based HTTP client for making API requests.
- **Chart.js**: Library for rendering charts and graphs.

## Installation

To set up the Currency Converter project locally, follow these steps:

1. **Clone the repository**:
   ```bash
   git clone https://github.com/yourusername/currency-converter.git
   cd currency-converter
   ```

2. **Install dependencies**:
   Make sure you have Node.js installed. Then run:
   ```bash
   npm install
   ```

3. **Set up your API key**:
   Replace `API_KEY` in the `views/index.ejs` file with your actual API key from the ExchangeRate-API.

4. **Start the server**:
   ```bash
   node server.js
   ```

5. **Access the application**:
   Open your web browser and navigate to `http://localhost:3000`.

## Usage

1. **Cover Page**: When you first access the application, you will see a cover page with a welcome message. After a few seconds, it will redirect to the main currency converter page.

2. **Currency Conversion**:
   - Enter the amount you want to convert.
   - Select the currency you want to convert from and the currency you want to convert to.
   - Click the "Convert" button to see the converted amount and the latest exchange rate displayed in a chart.

3. **Chart**: The chart will update dynamically based on the selected currency pair.

## Project Structure

currency-converter/
├── package.json
├── server.js
└── views/
├── cover.ejs
└── index.ejs


- **package.json**: Contains project metadata and dependencies.
- **server.js**: Main server file that sets up the Express application and routes.
- **views/**: Directory containing EJS templates for rendering HTML pages.

## Contributing

Contributions are welcome! If you have suggestions for improvements or new features, feel free to open an issue or submit a pull request.

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

## Acknowledgments

- [ExchangeRate-API](https://www.exchangerate-api.com/) for providing the exchange rate data.
- [Chart.js](https://www.chartjs.org/) for the charting library used in the application.