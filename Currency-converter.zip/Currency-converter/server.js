// server.js
const express = require('express');
const axios = require('axios');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Set EJS as the templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Middleware to parse request body
app.use(express.urlencoded({ extended: true }));

// Route to render the cover page
app.get('/', (req, res) => {
    res.render('cover'); // Render the cover page
});

// Route to render the main currency converter page
app.get('/converter', async (req, res) => {
    let currencies = [];
    try {
        const response = await axios.get('https://v6.exchangerate-api.com/v6/API_KEY/latest/USD'); // Replace with your API key
        currencies = Object.keys(response.data.conversion_rates);
    } catch (error) {
        console.error(error);
    }
    res.render('index', { currencies, convertedAmount: null, toCurrency: null, fromCurrency: null, error: null });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});